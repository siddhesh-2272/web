// ncr

const int N = 1e5;
ll fact[N + 1];
ll inv[N + 1];
const int mod = 1e9 + 7;
ll f_exp(ll a, ll b, int mod = 1e9 + 7)
{
    if (b < 0)
        return 0;
    ll res = 1;
    a %= mod;
    while (b)
    {
        if (b & 1)
        {
            res = (res * a) % mod;
        }
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}
void facts(int n, int mod = 1e9 + 7)
{
    fact[0] = 1;
    inv[0] = 1;
    for (int i = 1; i <= n; ++i)
    {
        fact[i] = (fact[i - 1] * i) % mod;
        inv[i] = f_exp(fact[i], mod - 2, mod);
    }
    // O(N * log(mod))
}
ll inv_mod(ll a, ll b, int mod = 1e9 + 7)
{
    return f_exp(a, b - 2, b);
}
ll nCr(ll n, ll r, int mod = 1e9 + 7)
{
    if (n < 0 || r < 0 || n < r)
        return 0;
    return (((fact[n] * inv[r]) % mod) * inv[n - r]) % mod;
}
ll NcR(ll n, ll r)
{
    if (n < 0 || r < 0 || n < r)
        return 0;
    ll ans = 1;
    for (int i = 1; i <= min(r, n - r); ++i)
    {
        ans = (ans * (n - i + 1)) / i;
    }
    return ans;
}

// mod functions

int power(int a, int b, int mod)
{
    a %= mod;
    int res = 1;
    while (b)
    {
        if (b & 1)
        {
            res = (res * a) % mod;
        }
        a = (a * a) % mod;
        b >>= 1;
    }
    return res;
}
int m_add(int a, int b, int mod)
{
    return (a % mod + b % mod + mod) % mod;
}
int m_sub(int a, int b, int mod)
{
    return ((a % mod - b % mod) % mod + mod) % mod;
}
int m_mul(int a, int b, int mod)
{
    return (a % mod * b % mod) % mod;
}
int m_div(int a, int b, int mod)
{
    return ((a % mod) * power(b, mod - 2, mod)) % mod;
}

// sieve for prime numbers
int n;
vector<bool> is_prime(n + 1, true);
void sieve()
{

    is_prime[0] = is_prime[1] = false;
    for (int i = 2; i * i <= n; i++)
    {
        if (is_prime[i])
        {
            for (int j = i * i; j <= n; j += i)
                is_prime[j] = false;
        }
    }
}

// Node structure for Trie
struct Node
{
    // Array to store links to child nodes,
    // each index represents a letter
    Node *links[26];
    // Flag indicating if the node
    // marks the end of a word
    bool flag = false;

    // Check if the node contains
    // a specific key (letter)
    bool containsKey(char ch)
    {
        return links[ch - 'a'] != NULL;
    }

    // Insert a new node with a specific
    // key (letter) into the Trie
    void put(char ch, Node *node)
    {
        links[ch - 'a'] = node;
    }

    // Get the node with a specific
    // key (letter) from the Trie
    Node *get(char ch)
    {
        return links[ch - 'a'];
    }

    // Set the current node
    // as the end of a word
    void setEnd()
    {
        flag = true;
    }

    // Check if the current node
    // marks the end of a word
    bool isEnd()
    {
        return flag;
    }
};

// Trie  implementation
class Trie
{
private:
    Node *root;

public:
    // Constructor to initialize the
    // Trie with an empty root node
    Trie()
    {
        root = new Node();
    }

    // Inserts a word into the Trie
    // Time Complexity O(len), where len
    // is the length of the word
    void insert(string word)
    {
        Node *node = root;
        for (int i = 0; i < word.length(); i++)
        {
            if (!node->containsKey(word[i]))
            {
                // Create a new node for
                // the letter if not present
                node->put(word[i], new Node());
            }
            // Move to the next node
            node = node->get(word[i]);
        }
        // Mark the end of the word
        node->setEnd();
    }

    // Returns if the word
    // is in the trie
    bool search(string word)
    {
        Node *node = root;
        for (int i = 0; i < word.length(); i++)
        {
            if (!node->containsKey(word[i]))
            {
                // If a letter is not found,
                // the word is not in the Trie
                return false;
            }
            // Move to the next node
            node = node->get(word[i]);
        }
        // Check if the last node
        // marks the end of a word
        return node->isEnd();
    }

    // Returns if there is any word in the
    // trie that starts with the given prefix
    bool startsWith(string prefix)
    {
        Node *node = root;
        for (int i = 0; i < prefix.length(); i++)
        {
            if (!node->containsKey(prefix[i]))
            {
                // If a letter is not found, there is
                // no word with the given prefix
                return false;
            }
            // Move to the next node
            node = node->get(prefix[i]);
        }
        // The prefix is found in the Trie
        return true;
    }
};
