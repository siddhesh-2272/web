def dist(p1, p2):
    d = 0
    for i in range(len(p1)):
        d += (p1[i] - p2[i]) ** 2
    return d ** 0.5

def mean(cluster):
    n = len(cluster[0])
    m = [0] * n
    for p in cluster:
        for i in range(n):
            m[i] += p[i]
    return [x / len(cluster) for x in m]

def kmeans(data, centroids, max_iters=100):
    k = len(centroids)

    for iteration in range(max_iters):
        clusters = [[] for _ in range(k)]  # Initialize clusters

        # Assign points to the nearest centroid
        for p in data:
            dists = [dist(p, c) for c in centroids]
            idx = dists.index(min(dists))
            clusters[idx].append(p)

        new_centroids = []
        for i in range(k):
            if clusters[i]:
                new_centroids.append(mean(clusters[i]))
            else:
                new_centroids.append(centroids[i])

        print(f"\nIteration {iteration + 1}:")
        for i, cluster in enumerate(clusters):
            print(f"Cluster {i + 1}: {cluster}")
        print(f"Centroids: {new_centroids}")

        if new_centroids == centroids:  # Check for convergence
            break
        centroids = new_centroids

    return clusters, centroids

def read_csv(filename):
    data = []
    with open(filename, 'r') as f:
        next(f)  # Skip header
        for line in f:
            line = line.strip()
            if line:
                point = list(map(float, line.split(',')))
                data.append(point)
    return data

if __name__ == "__main__":  # Corrected the if statement
    filename = r"input.csv"
    data = read_csv(filename)

    can_we_stop = True

    while can_we_stop:
        k = int(input("Enter the number of clusters (k): "))
        centroids = []

        for i in range(k):
            c = list(map(float, input(f"Centroid {i + 1}: ").split()))
            centroids.append(c)

        clusters, final_centroids = kmeans(data, centroids)

        print("\nFinal Clusters:")
        for i, cluster in enumerate(clusters):
            print(f"Cluster {i + 1}: {cluster}")

        print("\nFinal Centroids:")
        for c in final_centroids:
            print(c)

        stop = input("Can we stop? Enter 'y' for yes and 'n' for no: ")

        if stop.lower() == "y":  # Allowing for lowercase input
            can_we_stop = False
