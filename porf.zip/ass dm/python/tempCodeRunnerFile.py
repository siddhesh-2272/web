
input_file = 'input.csv'
output_file = 'output_min_max.csv'